
echo off

:loop
cls

echo.

..\bin\lsmidi.exe

pause > nul

goto loop
