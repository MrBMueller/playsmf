
 - MidiPorts.bat just lists all avilable inputs/outputs


playsmf style type example *.bat files

 - select the right midi input/output devices
 - if you have a smaller keyboard with less than 88 keys, you might need to adjust the key offset by one octave (e.g. -12) to reach all available functions
 - in some cases you need to adjust the output channel on your keyboard to attach to the right smf tracks for midi thru
