
@ echo off

setlocal EnableDelayedExpansion

:start
cls

echo:
echo. available midi devices (update list w/ ^<spacebar^>)
echo:

..\bin\lsmidi.exe " # key " "input" "output"

set lsmidi=%errorlevel%

set /a "InNum = (lsmidi / 0x1) & 0xffff"
set /a "OutNum = (lsmidi / 0x10000) & 0xffff"

echo:

if %InNum% leq 0 ( echo. no inputs detected - update list w/ ^<spacebar^> or proceed w/ default ^<return^>&& echo: )

..\bin\choice.exe " select primary input  : " 0 -1 %InNum%
if %errorlevel% leq -1 goto start
set input=%errorlevel%

..\bin\choice.exe " select primary output : " 0 -1 %OutNum%
if %errorlevel% leq -1 goto start
set output=%errorlevel%

echo:

..\bin\set.exe " enter key offset : " 0
set offset=%errorlevel%

echo:

..\bin\choice.exe " recording [N,Y]? " 0x0ff "" "nN" 0x0ff "yY" 0x8000
set rec=%errorlevel%

echo:

set smf=%1

set fc=!smf:~0,1!
set lc=!smf:~-1,1!

if !fc!==^" if !lc!==^" set smf=!smf:~1,-1!

if /i "!smf!" == "" ( set smf=..\mid\Style_3_4_2.mid)

echo. smf: "%smf%"

echo:

rem define key zones (left key, right key, attach track, thru delay, transpose, on, off velocity modifier)
set Zone0= 36  59  3  0  12 127 0   & rem left zone - chord
set Zone1= 60 127  4  0   0 127 0   & rem riht zone - melody

rem combine zones
set Zones= %Zone0% %Zone1%

rem define entry/exit messages (e.g. turn all notes + sustain pedal + local control off)
set ResetMsg= 0x03007bb0 0x030040b0
set LocalCtl= 0x01007abf 0x027f7abf

rem define text message printing (default: turn all text meassges off)
set text=0x50000

..\bin\playsmf.exe "%smf%" -1 %output% %input% -1 -2 %offset% %rec% 0x7fffa199  21 22  %Zones%  %ResetMsg% %LocalCtl% %text%
